#include <SFML/Graphics.hpp>
using namespace sf;

#ifndef BULLET_H
#define BULLET_H

class Bullet
{
public:
    Texture bull;
    Sprite bullet;
    float b_speed = 0.4;
    static int b_n;
    bool bull_exist;
    bool visibiity;
    bool bullet_effect;
    Bullet(){}
    Bullet(std::string png_path, int x, int y, float speed);
    void move_left();
    void move_left1();
    void move_left2();
    void move_left4();
    void move_right();
    void move_right1();
    void move_right2();
    void move_right4();
    void move();
    void move_down();
    int get_y();
    int get_x();
};
int Bullet::b_n = 0;

#endif /* BULLET_H */
