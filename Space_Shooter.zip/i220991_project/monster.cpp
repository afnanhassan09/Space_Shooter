#include"monster.h"

Monster::Monster()
{
    enemy.loadFromFile("img/monster1.png");
    sprite.setTexture(enemy);
    sprite.setPosition(350, 0);
    score = 50;
    visibility = true;
    sprite.setScale(0.75, 0.75);
}

void Monster::move(bool moveRight)
{
    float delta_x = 0, delta_y = 0;
    if (moveRight)
        delta_x = 1;
    else
        delta_x = -1;
    delta_x *= speed;
    delta_y *= speed;
    sprite.move(delta_x, delta_y);
}
void Monster::fire_beam()
{
    b = new Beam(sprite.getPosition().x, sprite.getPosition().y);
}