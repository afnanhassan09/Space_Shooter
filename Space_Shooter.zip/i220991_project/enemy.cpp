#include"enemy.h"

Enemy::Enemy(std::string png_path, int x, int y)
{
    bull_visibility = false;
    enemy.loadFromFile(png_path);
    sprite.setTexture(enemy);
    sprite.setPosition(x, y);
    sprite.setScale(0.75, 0.75);
    visibility = true;
}
// // virtual void fire(bool &i) = 0;
// virtual void move() = 0;
int Enemy::get_x() { return sprite.getPosition().x; }
int Enemy::get_y() { return sprite.getPosition().y; }