#include <iostream>
#include "enemy.h"
#include"beam.h"


using namespace std;
#ifndef C42A5905_0E8A_426A_A156_B8D414C7DB2F
#define C42A5905_0E8A_426A_A156_B8D414C7DB2F

class Monster : public Enemy
{

public:
    Beam *b;
    float speed = 0.2;
    Monster();
    virtual void move(bool moveRight);
    void fire_beam();
};

#endif /* C42A5905_0E8A_426A_A156_B8D414C7DB2F */
