#include <SFML/Graphics.hpp>
#include "bomb.h"
#include"enemy.h"
using namespace sf;
using namespace std;
#ifndef DF5C941C_E630_4C67_A723_1233735BC158
#define DF5C941C_E630_4C67_A723_1233735BC158

class Invader: public Enemy
{
public:
    float speed = 0.5;
    float bull_interval;
    string type;
    Invader() {}
    Invader(std::string png_path, int x, int y);
    virtual void fire(bool &i) = 0;
    int get_x();
    int get_y();
    float sp;
};

#endif /* DF5C941C_E630_4C67_A723_1233735BC158 */
