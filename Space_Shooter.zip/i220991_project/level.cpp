#include"level.h"

Level1::Level1()
{
    e = new Invader *[12];
}
void Level1::display_1()
{
    e[1] = new Alpha(510, 90);
    e[0] = new Beta(360, 235);  //
    e[2] = new Alpha(200, 90);  //
    e[5] = new Alpha(510, 380); //
    e[6] = new Alpha(200, 380); //
    e[3] = new Alpha(0, 0);
    e[3]->visibility = false;
    e[4] = new Alpha(0, 0);
    e[4]->visibility = false;
    e[7] = new Alpha(0, 0);
    e[7]->visibility = false;
    e[8] = new Alpha(0, 0);
    e[8]->visibility = false;
    e[9] = new Alpha(0, 0);
    e[9]->visibility = false;
    e[10] = new Alpha(0, 0);
    e[10]->visibility = false;
    e[11] = new Alpha(0, 0);
    e[11]->visibility = false;
}
void Level1::display_2()
{
    // cout << "level 2 called\n";
    delete e[0];
    delete e[1];
    delete e[2];
    delete e[5];
    delete e[6];
    delete e[7];
    e[0] = new Beta(360, 50);
    e[0]->visibility = true;
    e[1] = new Alpha(480, 170);
    e[1]->visibility = true;
    e[2] = new Alpha(230, 170);
    e[2]->visibility = true;
    e[5] = new Alpha(100, 300);
    e[5]->visibility = true;
    e[6] = new Alpha(360, 300);
    e[6]->visibility = true;
    e[7] = new Alpha(600, 300);
    e[7]->visibility = true;
}

void Level1::display_3()
{
    // cout << "level 3 called\n";
    delete e[0];
    delete e[1];
    delete e[2];
    delete e[5];
    delete e[6];
    delete e[7];

    e[0] = new Gamma(360, 50);
    e[1] = new Alpha(100, 220);
    e[3] = new Beta(100, 50);
    e[4] = new Beta(600, 50);
    e[2] = new Alpha(600, 220);
    e[5] = new Alpha(100, 350);
    e[6] = new Alpha(360, 350);
    e[7] = new Alpha(600, 350);
}
void Level1::display_4()
{
    // cout << "level 4 called\n";
    delete e[0];
    delete e[1];
    delete e[2];
    delete e[3];
    delete e[5];
    delete e[6];
    delete e[7];
    e[0] = new Gamma(350, 30);
    e[1] = new Alpha(100, 270);
    e[2] = new Alpha(620, 270);
    e[3] = new Beta(150, 100);
    e[4] = new Beta(570, 100);
    e[6] = new Alpha(380, 480);
    e[5] = new Alpha(150, 400);
    e[7] = new Alpha(550, 400);
}
void Level1::display_5()
{
    // cout << "level 5 called\n";
    delete e[0];
    delete e[1];
    delete e[2];
    delete e[3];
    delete e[5];
    delete e[6];
    delete e[7];

    e[1] = new Alpha(100, 220);
    e[3] = new Beta(140, 50);
    e[5] = new Alpha(170, 350);
    e[0] = new Gamma(360, 100);
    e[6] = new Alpha(370, 450);
    e[2] = new Alpha(630, 220);
    e[4] = new Beta(600, 50);
    e[7] = new Alpha(550, 350);
}
void Level1::display_6()
{
    // cout << "level 6 called\n";
    delete e[0];
    delete e[1];
    delete e[2];
    delete e[3];
    delete e[5];
    delete e[6];
    delete e[7];

    e[0] = new Gamma(350, 30);
    e[6] = new Alpha(380, 480);
    e[1] = new Alpha(100, 270);
    e[2] = new Alpha(620, 270);
    e[3] = new Beta(240, 140);
    e[4] = new Beta(490, 140);
    e[5] = new Beta(490, 375);
    e[7] = new Beta(240, 375);
}
void Level1::display_7()
{
    // cout << "level 6 called\n";
    delete e[0];
    delete e[1];
    delete e[2];
    delete e[3];
    delete e[5];
    delete e[6];
    delete e[7];
    delete e[8];
    delete e[9];

    e[0] = new Gamma(350, 30);
    e[6] = new Alpha(380, 500);
    e[1] = new Alpha(100, 270);
    e[2] = new Alpha(620, 270);
    e[10] = new Beta(240, 270);
    e[11] = new Beta(490, 270);
    e[3] = new Beta(240, 140);
    e[4] = new Beta(490, 140);
    e[5] = new Beta(490, 375);
    e[7] = new Beta(240, 375);
    e[9] = new Beta(350, 375);
    e[8] = new Beta(350, 140);
}
void Level1::display_8()
{
    // cout << "level 6 called\n";
    delete e[0];
    delete e[1];
    delete e[2];
    delete e[3];
    delete e[5];
    delete e[6];
    delete e[7];
    delete e[8];
    delete e[9];

    e[0] = new Gamma(350, 30);
    e[1] = new Alpha(100, 270);
    e[2] = new Alpha(620, 270);
    e[3] = new Beta(150, 100);
    e[4] = new Beta(570, 100);
    e[6] = new Alpha(380, 480);
    e[5] = new Alpha(150, 400);
    e[7] = new Alpha(550, 400);
    e[10] = new Beta(240, 260);
    e[11] = new Beta(490, 260);
    e[9] = new Beta(350, 360);
    e[8] = new Beta(370, 140);
}

void Level1::display_9()
{
    // cout << "level 6 called\n";
    delete e[0];
    delete e[1];
    delete e[2];
    delete e[3];
    delete e[5];
    delete e[6];
    delete e[7];
    delete e[8];
    delete e[9];

    e[1] = new Alpha(100, 220);
    e[3] = new Beta(140, 50);
    e[5] = new Alpha(170, 350);
    e[0] = new Gamma(360, 100);
    e[6] = new Alpha(370, 450);
    e[2] = new Alpha(630, 220);
    e[4] = new Beta(600, 50);
    e[7] = new Alpha(550, 350);
    e[10] = new Beta(240, 180);
    e[11] = new Beta(490, 180);
    e[9] = new Beta(370, 330);
    e[8] = new Beta(370, 240);
}

void Level1::showMonster(bool &m)
{
    monster = new Monster;
    m = true;
}
void Level1::showDragon(bool &m)
{
    dragon = new Dragon;
    m = true;
}
void Level1::enemy_collision()
{
    e1 = new Gamma(-100, 350);
    e2 = new Gamma(800, 350);
}