#include <iostream>
#include "enemy.h"
#include "fire.h"
#ifndef C022084F_717E_4563_AE6C_AEAA5DE861BF
#define C022084F_717E_4563_AE6C_AEAA5DE861BF

class Dragon : public Enemy 
{
    public:
        D_Fire *fire;
        Dragon();
        void fire1();
        void fire2();
        void fire3();
};


#endif /* C022084F_717E_4563_AE6C_AEAA5DE861BF */
