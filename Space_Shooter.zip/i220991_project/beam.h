#include <SFML/Graphics.hpp>
using namespace sf;
#ifndef F3CE25B5_D91D_4D5B_81B8_FD43AE820B47
#define F3CE25B5_D91D_4D5B_81B8_FD43AE820B47

class Beam
{
    public:
    Texture bull;
    Sprite bullet;
    float speed = 0.2;
    Beam(){}
    Beam(int x, int y)
    {
        bull.loadFromFile("img/beam.png");
        bullet.setTexture(bull);
        bullet.setPosition(x+40, y+140);
        
    }
    void move(bool moveRight)
    {
        float delta_x = 0, delta_y = 0;
        if (moveRight)
            delta_x = 1;
        else
            delta_x = -1;
        delta_x *= speed;
        delta_y *= speed;
        bullet.move(delta_x, delta_y);
    }
};

#endif /* F3CE25B5_D91D_4D5B_81B8_FD43AE820B47 */
