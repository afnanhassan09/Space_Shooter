#include <iostream>
#include "enemy.h"
#include "beam.h"
#ifndef BDA96BAD_1156_4913_949B_05A654944607
#define BDA96BAD_1156_4913_949B_05A654944607

class D_Fire : public Beam
{
    public:
    D_Fire()
    {
        bull.loadFromFile("img/dragon_fire.png");
        bullet.setTexture(bull);
        bullet.setPosition(170,200);
        bullet.setScale(0.5, 0.5);
    }
    D_Fire(int x)
    {
        bull.loadFromFile("img/dragonfire_left.png");
        bullet.setTexture(bull);
        bullet.setPosition(-390, 90);
        bullet.setScale(0.5, 0.5);
    }
    D_Fire(bool a)
    {
        bull.loadFromFile("img/dragonfire_right.png");
        bullet.setTexture(bull);
        bullet.setPosition(180, 60);
        bullet.setScale(0.5, 0.5);
    }

};

#endif /* BDA96BAD_1156_4913_949B_05A654944607 */
