#include <SFML/Graphics.hpp>
using namespace sf;

#ifndef BOMB_H
#define BOMB_H

class Bomb
{
public:
    Texture bull;
    Sprite bullet;
    float b_speed = 0.4;
    bool bull_exist;
    bool visibiity;
    bool bullet_effect;
    Bomb() {}
    Bomb(std::string png_path, int x, int y, float speed = 0.6)
    {
        bull.loadFromFile(png_path);
        bullet.setTexture(bull);
        bullet.setPosition(x, y);
        bullet.setScale(1, 1);
        b_speed = speed;
        visibiity = true;
        bullet_effect = true;
    }

    void move_down(std::string s = "d")
    {
        float delta_x = 0, delta_y = 0;
        if (s == "d")
            delta_y = 1;
        delta_x *= b_speed;
        delta_y *= b_speed;

        bullet.move(delta_x, delta_y);
    }
    int get_y()
    {
        int x = bullet.getPosition().y;
        return x;
    }
    int get_x()
    {
        int a = bullet.getPosition().x;
        return a;
    }
};

#endif /* BOMB_H */

