#include"player.h"

Player::Player(string png_path)
{
    SoundBuffer buffer2;
    if (!buffer2.loadFromFile("Sounds/ship_destroy.ogg"))
    {
        // Error loading sound file
    }
    sound_destroy.setBuffer(buffer2);
    font.loadFromFile("img/PNG/UI/numeral3.png");
    life.setTexture(font);
    life.setPosition(110, 700);
    life.setScale(2, 2);
    ex.loadFromFile("img/PNG/Lasers/laserRed08.png");
    explosion.setTexture(ex);
    explosion.setPosition(340, 700);
    explosion.setScale(1, 1);
    sheild.loadFromFile("img/PNG/Effects/shield1.png");
    Sheild.setTexture(sheild);
    tex.loadFromFile(png_path);
    sprite.setTexture(tex);

    x = 340;
    y = 700;
    sprite.setPosition(x, y);
    sprite.setScale(0.75, 0.75);
    lives = 3;
    add_life = nullptr;
    onFire = false;
    PowerMode = false;
    showShield = false;
    UltraFire = false;
    score = 0;
    tiltedLeft = false;
    tiltedRight = false;
}

void Player::fire1(int &i, bool &bull_effect)
{
    if (tiltedLeft)
    {
        b1 = new Bullet("img/left_bullet.png", sprite.getPosition().x - 20, sprite.getPosition().y + 10, 1);
    }
    else if (tiltedRight)
    {
        b1 = new Bullet("img/right_bullet.png", sprite.getPosition().x + 31, sprite.getPosition().y + 10, 1);
    }
    else if (!onFire)
        b1 = new Bullet("img/PNG/Lasers/laserBlue01.png", sprite.getPosition().x + 31, sprite.getPosition().y + 10, 1);
    else
        b1 = new Bullet("img/PNG/Lasers/laserRed16.png", sprite.getPosition().x + 31, sprite.getPosition().y + 10, 1);
    i = 1;
    bull_effect = true;
}
void Player::fire2(int &i, bool &bull_effect)
{
    if (tiltedLeft)
    {
        b2 = new Bullet("img/left_bullet.png", sprite.getPosition().x - 20, sprite.getPosition().y + 10, 1);
    }
    else if (tiltedRight)
    {
        b2 = new Bullet("img/right_bullet.png", sprite.getPosition().x + 31, sprite.getPosition().y + 10, 1);
    }
    else if (!onFire)
        b2 = new Bullet("img/PNG/Lasers/laserBlue01.png", sprite.getPosition().x + 31, sprite.getPosition().y + 10, 1);
    else
        b2 = new Bullet("img/PNG/Lasers/laserRed16.png", sprite.getPosition().x + 31, sprite.getPosition().y + 10, 1);
    i = 1;
    bull_effect = true;
}
void Player::fire3(int &i, bool &bull_effect)
{
    if (tiltedLeft)
    {
        b3 = new Bullet("img/left_bullet.png", sprite.getPosition().x - 20, sprite.getPosition().y + 10, 1);
    }
    else if (tiltedRight)
    {
        b3 = new Bullet("img/right_bullet.png", sprite.getPosition().x + 31, sprite.getPosition().y + 10, 1);
    }
    else if (!onFire)
        b3 = new Bullet("img/PNG/Lasers/laserBlue01.png", sprite.getPosition().x + 31, sprite.getPosition().y + 10, 1);
    else if (onFire)
    {
        b3 = new Bullet("img/PNG/Lasers/laserRed16.png", sprite.getPosition().x + 31, sprite.getPosition().y + 10, 1);
    }
    i = 1;
    bull_effect = true;
}
void Player::enemy_1(int &l1e1)
{
    cout << "calling\n";
    l1.display_1();
    l1e1 = 1;
}
void Player::enemy_2(int &l1e1)
{
    l1.display_2();
    l1e1 = 1;
}

void Player::enemy_3(int &l1e1)
{
    l1.display_3();
    l1e1 = 1;
}
void Player::enemy_4(int &l1e1)
{
    l1.display_4();
    l1e1 = 1;
}
void Player::enemy_5(int &l1e1)
{
    l1.display_5();
    l1e1 = 1;
}
void Player::enemy_6(int &l1e1)
{
    l1.display_6();
    l1e1 = 1;
}
void Player::enemy_7(int &l1e1)
{
    l1.display_7();
    l1e1 = 1;
}
void Player::enemy_8(int &l1e1)
{
    l1.display_8();
    l1e1 = 1;
}
void Player::enemy_9(int &l1e1)
{
    l1.display_9();
    l1e1 = 1;
}
void Player::collision(bool &a)
{
    l1.enemy_collision();
    a = true;
}
void Player::Addon_life(int &i)
{
    add_life = new Lives;
    i = 1;
}
void Player::Addon_fire(int &i)
{
    catch_fire = new Fire;
    i = 1;
}
void Player::Addon_powerup(int &i)
{
    power = new PowerUp;
    i = 1;
}
void Player::Addon_danger(int &i)
{
    danger = new Danger;
    i = 1;
}
void Player::check_fire(int &i)
{
    if (catch_fire->sprite.getPosition().y > sprite.getPosition().y - 1 && catch_fire->sprite.getPosition().y < sprite.getPosition().y + 100)
    {
        if (catch_fire->sprite.getPosition().x > sprite.getPosition().x - 50 && catch_fire->sprite.getPosition().x < sprite.getPosition().x + 50)
        {
            onFire = true;
            i = 0;
        }
    }
}
void Player::check_power(int &i)
{
    if (power->sprite.getPosition().y > sprite.getPosition().y - 1 && power->sprite.getPosition().y < sprite.getPosition().y + 100)
    {
        if (power->sprite.getPosition().x > sprite.getPosition().x - 50 && power->sprite.getPosition().x < sprite.getPosition().x + 50)
        {
            PowerMode = true;
            showShield = true;
            UltraFire = true;
            i = 0;
        }
    }
}
void Player::check_danger(int &i, int &sv, bool &c)
{
    if (danger->sprite.getPosition().y > sprite.getPosition().y - 1 && danger->sprite.getPosition().y < sprite.getPosition().y + 50)
    {
        if (danger->sprite.getPosition().x > sprite.getPosition().x - 25 && danger->sprite.getPosition().x < sprite.getPosition().x + 70)
        {
            destroy_ship(sv, c);
            i = 0;
        }
    }
}
void Player::ultrafire1(int &i)
{
    b4 = new Bullet *[7];
    for (int j = 0; j < 7; j++)
    {
        b4[j] = new Bullet("img/PNG/Lasers/laserBlue01.png", sprite.getPosition().x + 31, sprite.getPosition().y + 10, 1);
    }
    i = 1;
}
void Player::ultrafire2(int &i)
{
    b5 = new Bullet *[7];
    for (int j = 0; j < 7; j++)
    {
        b5[j] = new Bullet("img/PNG/Lasers/laserBlue01.png", sprite.getPosition().x + 31, sprite.getPosition().y + 10, 1);
    }
    i = 1;
}

void Player::ultrafire3(int &i)
{
    b6 = new Bullet *[7];
    for (int j = 0; j < 7; j++)
    {
        b6[j] = new Bullet("img/PNG/Lasers/laserBlue01.png", sprite.getPosition().x + 31, sprite.getPosition().y + 10, 1);
    }
    i = 1;
}
void Player::check_life(int &i)
{
    if (add_life->sprite.getPosition().y > sprite.getPosition().y - 1 && add_life->sprite.getPosition().y < sprite.getPosition().y + 100)
    {
        if (add_life->sprite.getPosition().x > sprite.getPosition().x - 50 && add_life->sprite.getPosition().x < sprite.getPosition().x + 50)
        {
            i = 0;
            lives++;
        }
    }
}
void Player::move(string s)
{
    float delta_x = 0, delta_y = 0;
    if (s == "l")
        delta_x = -1;
    else if (s == "r")
        delta_x = 1;
    if (s == "u")
        delta_y = -1;
    else if (s == "d")
        delta_y = 1;

    delta_x *= speed;
    delta_y *= speed;

    sprite.move(delta_x, delta_y);
}

void Player::Boundary_check()
{
    int a, b;
    a = sprite.getPosition().x;
    b = sprite.getPosition().y;
    if (a < -40)
        sprite.setPosition(740, b);
    else if (a > 740)
        sprite.setPosition(-40, b);
    else if (b > 700)
        sprite.setPosition(a, 700);
    else if (b < 0)
        sprite.setPosition(a, 700);
}
void Player::loadlife()
{
    if (lives == 2)
    {
        font.loadFromFile("img/PNG/UI/numeral2.png");
        life.setTexture(font);
        life.setPosition(150, 740);
    }

    else if (lives == 1)
    {
        font.loadFromFile("img/PNG/UI/numeral1.png");
        life.setTexture(font);
        life.setPosition(150, 740);
    }
    else if (lives == 3)
    {
        font.loadFromFile("img/PNG/UI/numeral3.png");
        life.setTexture(font);
        life.setPosition(150, 740);
    }
    else if (lives == 5)
    {
        font.loadFromFile("img/PNG/UI/numeral5.png");
        life.setTexture(font);
        life.setPosition(150, 740);
    }
    else if (lives == 0)
    {
        font.loadFromFile("img/PNG/UI/numeral0.png");
        life.setTexture(font);
        life.setPosition(150, 740);
    }
    else if (lives == 4)
    {
        font.loadFromFile("img/PNG/UI/numeral4.png");
        life.setTexture(font);
        life.setPosition(150, 740);
    }
    else if (lives < 0)
    {
        font.loadFromFile("img/PNG/UI/numeralX.png");
        life.setTexture(font);
        life.setPosition(150, 740);
    }
}
void Player::destroy_ship(int &sv, bool &c)
{
    if (!showShield)
    {
        c = true;
        lives--;
        // cout << lives;
        explosion.setPosition(sprite.getPosition().x - 10, sprite.getPosition().y - 30);
        sv = 0;
    }
}
void Player::destroy_enemy(int &l1e1, bool &bull_effect)
{

    if (!UltraFire)
    {
        for (int i = 0; i < 12; i++)
        {
            if (l1e1 && l1.e[i]->visibility && bull_effect)
                if (b1->get_y() == l1.e[i]->get_y() + 20)
                {

                    if (b1->get_x() > l1.e[i]->get_x() - 40 + 30 && b1->get_x() < l1.e[i]->get_x() + 120)
                    {
                        if (!onFire)
                        {
                            bull_effect = false;
                            b1->visibiity = false;
                        }
                        l1.e[i]->visibility = false;
                        score += l1.e[i]->score;
                    }
                }
        }
    }
}
void Player::destroy_enemy2(int &l1e1, bool &bull_effect2)
{
    if (!UltraFire)
    {
        for (int i = 0; i < 12; i++)
        {
            if (l1e1 && l1.e[i]->visibility && bull_effect2)
                if (b2->get_y() == l1.e[i]->get_y() + 20)
                {

                    if (b2->get_x() > l1.e[i]->get_x() - 40 + 30 && b2->get_x() < l1.e[i]->get_x() + 120)
                    {
                        l1.e[i]->visibility = false;
                        if (!onFire)
                        {
                            bull_effect2 = false;
                            b2->visibiity = false;
                        }
                        score += l1.e[i]->score;
                    }
                }
        }
    }
}
void Player::destroy_enemy3(int &l1e1, bool &bullet_effect)
{
    if (!UltraFire)
    {
        for (int i = 0; i < 12; i++)
        {
            if (l1e1 && l1.e[i]->visibility && bullet_effect)
                if (b3->get_y() == l1.e[i]->get_y() + 20)
                {

                    if (b3->get_x() > l1.e[i]->get_x() - 40 + 30 && b3->get_x() < l1.e[i]->get_x() + 120)
                    {
                        l1.e[i]->visibility = false;
                        if (!onFire)
                        {
                            bullet_effect = false;
                            b3->visibiity = false;
                        }
                        score += l1.e[i]->score;
                    }
                }
        }
    }
}
void Player::ultra_fireDestroy1(int &l1e1)
{
    if (UltraFire && l1e1)
    {
        for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < 12; j++)
            {
                if (1e1 && l1.e[j]->visibility && b4[i]->bullet_effect)
                {
                    if (b4[i]->get_y() == l1.e[j]->get_y() + 20)
                        if (b4[i]->get_x() > l1.e[j]->get_x() - 40 + 30 && b4[i]->get_x() < l1.e[j]->get_x() + 120)
                        {
                            l1.e[j]->visibility = false;
                            b4[i]->bullet_effect = false;
                            b4[i]->visibiity = false;
                            score += l1.e[j]->score;
                        }
                }
            }
        }
    }
}
void Player::ultra_fireDestroy2(int &l1e1)
{
    if (UltraFire && l1e1)
    {
        for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < 12; j++)
            {
                if (1e1 && l1.e[j]->visibility && b5[i]->bullet_effect)
                {
                    if (b5[i]->get_y() == l1.e[j]->get_y() + 20)
                        if (b5[i]->get_x() > l1.e[j]->get_x() - 40 + 30 && b5[i]->get_x() < l1.e[j]->get_x() + 120)
                        {
                            l1.e[j]->visibility = false;
                            b5[i]->bullet_effect = false;
                            b5[i]->visibiity = false;
                            score += l1.e[j]->score;
                        }
                }
            }
        }
    }
}
void Player::ultra_fireDestroy3(int &l1e1)
{
    if (UltraFire && l1e1)
        for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < 12; j++)
            {
                if (1e1 && l1.e[j]->visibility && b6[i]->bullet_effect)
                {
                    if (b6[i]->get_y() == l1.e[j]->get_y() + 20)
                        if (b6[i]->get_x() > l1.e[j]->get_x() - 40 + 30 && b6[i]->get_x() < l1.e[j]->get_x() + 120)
                        {
                            l1.e[j]->visibility = false;
                            b6[i]->bullet_effect = false;
                            b6[i]->visibiity = false;
                            score += l1.e[j]->score;
                        }
                }
            }
        }
}