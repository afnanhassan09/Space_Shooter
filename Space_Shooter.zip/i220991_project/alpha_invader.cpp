#include"alpha_invader.h"

Alpha::Alpha(int x, int y) : Invader("img/enemy_1.png", x, y)
{
    type = "Alpha";
    bull_interval = 5;
    score = 10;
    sp = 0.2;
}
void Alpha::fire(bool &i)
{
    b = new Bomb("img/enemy_laser.png", sprite.getPosition().x + 38, sprite.getPosition().y + 10, sp);
    i = 1;
}