#include"gamma.invader.h"

Gamma::Gamma(int x, int y) : Invader("img/enemy_3.png", x, y)
{
    type = "Gamma";
    bull_interval = 5;
    score = 30;
    sp = 0.4;
}
void Gamma::fire(bool &i)
{
    b = new Bomb("img/enemy_laser.png", sprite.getPosition().x + 38, sprite.getPosition().y + 10, sp);
    i = 1;
}
void Gamma::Movel()
{
    float delta_x = -1, delta_y = 0;
    delta_x *= 0.4;
    delta_y *= 0.4;
    sprite.move(delta_x, delta_y);
}
void Gamma::Mover()
{
    float delta_x = 1, delta_y = 0;
    delta_x *= 0.4;
    delta_y *= 0.4;
    sprite.move(delta_x, delta_y);
}