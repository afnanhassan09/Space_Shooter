#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <time.h>
#include <iostream>
#include"enemy.h"
#include"alpha_invader.cpp"
#include"beta_invader.cpp"
#include"gamma.invader.cpp"
#include"monster.cpp"
#include"dragon.cpp"
using namespace std;
using namespace sf;

class Level
{
public:
    int enemy_number;
    string shape;
    int score;
};

class Level1 : public Level
{
public:
    Invader **e;
    Monster *monster;
    Dragon *dragon;
    Gamma *e1;
    Gamma *e2;
    Level1();
    void display_1();
    void display_2();
    void display_3();
    void display_4();
    void display_5();
    void display_6();
    void display_7();
    void display_8();

    void display_9();

    void showMonster(bool &m);
    void showDragon(bool &m);
    void enemy_collision();
};
