#include <SFML/Graphics.hpp>
#include <cstdlib>
using namespace sf;
using namespace std;
#ifndef DC60178F_9CBA_4450_95C9_9583DF51880E
#define DC60178F_9CBA_4450_95C9_9583DF51880E

class AddOns
{
public:
    Texture text;
    Sprite sprite;
    float f_speed;
    bool visibility;

    AddOns(string png_path);
    virtual void move() = 0;
};

#endif