#include"invader.h"

Invader::Invader(std::string png_path, int x, int y)
{
    visibility = false;
    bull_visibility = false;
    enemy.loadFromFile(png_path);
    sprite.setTexture(enemy);
    sprite.setPosition(x, y);
    sprite.setScale(0.75, 0.75);
    visibility = true;
}
int Invader::get_x() { return sprite.getPosition().x; }
int Invader::get_y() { return sprite.getPosition().y; }