#include <iostream>
#include "addon.h"
#ifndef C50B9919_10C8_4A8F_8335_BE2E2F3A19DC
#define C50B9919_10C8_4A8F_8335_BE2E2F3A19DC

class Danger : public AddOns
{
public:
    Danger();
    void move();
};

#endif /* C50B9919_10C8_4A8F_8335_BE2E2F3A19DC */
