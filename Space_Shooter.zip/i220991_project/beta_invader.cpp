#include"beta_invader.h"

Beta::Beta(int x, int y) : Invader("img/enemy_2.png", x, y)
{
    type = "Beta";
    bull_interval = 3;
    score = 20;
    sp = 0.4;
}
void Beta::fire(bool &i)
{
    b = new Bomb("img/enemy_laser.png", sprite.getPosition().x + 38, sprite.getPosition().y + 10, sp);
    i = 1;
}