#include<iostream>
#include"addon.h"
#ifndef A1727660_7142_4632_BC28_E9EC07B02393
#define A1727660_7142_4632_BC28_E9EC07B02393

class Fire : public AddOns
{
public:
    Fire();
    void move();
};
#endif /* A1727660_7142_4632_BC28_E9EC07B02393 */
