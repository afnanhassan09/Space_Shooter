#include <iostream>
#include <SFML/Graphics.hpp>
#include "bomb.h"
using namespace sf;
using namespace std;
#ifndef B9B33AFF_B89A_4E9B_810F_7F1F97435491
#define B9B33AFF_B89A_4E9B_810F_7F1F97435491
class Enemy
{
public:
    Bomb *b;
    int hp;
    int damage;
    Texture enemy;
    Sprite sprite;
    bool visibility;
    bool bull_visibility;
    float speed = 0.5;
    float bull_interval;
    string type;
    int score;
    Enemy() {}
    Enemy(std::string png_path, int x, int y);
    // // virtual void fire(bool &i) = 0;
    // virtual void move() = 0;
    int get_x();
    int get_y();
};

#endif /* B9B33AFF_B89A_4E9B_810F_7F1F97435491 */
