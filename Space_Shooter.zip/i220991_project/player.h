#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <time.h>
#include <cstdlib>
#include "bullet.cpp"
#include "invader.cpp"
#include "level.cpp"
#include "addon.cpp"
#include "fire_addon.cpp"
#include "danger_addon.cpp"
#include "life_addon.cpp"
#include "powerup_addon.cpp"
#include <string.h>
using namespace sf;
using namespace std;
class Player
{
public:
    Sound sound_destroy;
    Texture tex;
    Sprite sprite;
    Texture l_tex;
    Sprite l_sprite;
    Texture r_tex;
    Sprite r_sprite;

    Texture ex;
    Level1 l1;
    Sprite explosion;
    float speed = 0.4;
    Bullet *b1;
    Bullet *b2;
    Bullet *b3;
    Bullet **b4;
    Bullet **b5;
    Bullet **b6;
    bool tiltedRight;
    bool tiltedLeft;
    Invader *e;
    AddOns *add_life;
    AddOns *catch_fire;
    AddOns *power;
    AddOns *danger;
    bool crash = false;
    int x, y;
    int lives = 3;
    int explosion_x;
    int explosion_y;
    bool onFire;
    bool PowerMode;
    bool showShield;
    bool UltraFire;
    Texture font;
    Sprite life;
    int score;
    Texture sheild;
    Sprite Sheild;

    Player(string png_path);

    void fire1(int &i, bool &bull_effect);
    void fire2(int &i, bool &bull_effect);
    void fire3(int &i, bool &bull_effect);
    void enemy_1(int &l1e1);
    void enemy_2(int &l1e1);
    void enemy_3(int &l1e1);
    void enemy_4(int &l1e1);
    void enemy_5(int &l1e1);
    void enemy_6(int &l1e1);
    void enemy_7(int &l1e1);
    void enemy_8(int &l1e1);
    void enemy_9(int &l1e1);
    void collision(bool &a);
    void Addon_life(int &i);
    void Addon_fire(int &i);
    void Addon_powerup(int &i);
    void Addon_danger(int &i);
    void check_fire(int &i);
    void check_power(int &i);
    void check_danger(int &i, int &sv, bool &c);
    void ultrafire1(int &i);
    void ultrafire2(int &i);
    void ultrafire3(int &i);
    void check_life(int &i);
    void move(string s);
    void Boundary_check();
    void loadlife();
    void destroy_ship(int &sv, bool &c);
    void destroy_enemy(int &l1e1, bool &bull_effect);
    void destroy_enemy2(int &l1e1, bool &bull_effect2);
    void destroy_enemy3(int &l1e1, bool &bullet_effect);
    void ultra_fireDestroy1(int &l1e1);
    void ultra_fireDestroy2(int &l1e1);
    void ultra_fireDestroy3(int &l1e1);
};
