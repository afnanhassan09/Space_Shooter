#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <fstream>
#include <time.h>
#include <iostream>
using namespace std;
#include "player.cpp"
const char title[] = "OOP-Project, Spring-2023";
using namespace sf;

class Game
{
public:
    Sprite background;
    Texture bg_texture;
    Player *p; // player
    SoundBuffer buffer1;
    Sound sound_destroy;
    Texture ps;
    Sprite Pause;
    bool leftbullet1 = false;
    bool rightbullet1 = false;
    bool leftbullet2 = false;
    bool show_endMenu = false;
    bool rightbullet2 = false;
    bool leftbullet3 = false;
    bool rightbullet3 = false;
    SoundBuffer monster_file;
    Sound monster_sound;
    bool crash = false;
    bool soundPlayed = false;
    bool monster_beam = false;
    int e_l = 0;
    bool leftfire = false;
    bool rightfire = false;
    bool firing = false;
    bool monster_end = false;
    bool firing2 = false, firing3 = false;
    bool bull_effect1 = true;
    bool bull_effect2 = true;
    bool bull_effect3 = true;
    bool bul_interval = true;
    bool bul_interval2 = true;
    bool bul_interval3 = true;
    bool monster = false;
    bool m_moveRight = true;
    int li = 0;
    int fi = 0;
    int pu = 0;
    int dg = 0;
    bool show_dragon1 = false;
    float dragon_showing = 0;
    float monster_ending = 0;
    float stop_interval = 0;
    float endtimer = 0;
    // add other game attributes

    Game();
    void start_game(bool &restart, string playerName);
};
