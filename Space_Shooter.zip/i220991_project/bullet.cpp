#include"bullet.h"

Bullet::Bullet(std::string png_path, int x, int y, float speed = 0.6)
{
    bull.loadFromFile(png_path);
    bullet.setTexture(bull);
    bullet.setPosition(x, y);
    bullet.setScale(1, 1);
    b_speed = speed;
    b_n++;
    visibiity = true;
    bullet_effect = true;
}
void Bullet::move_left()
{
    float delta_x = -0.75, delta_y = -0.6;
    delta_x *= b_speed;
    delta_y *= b_speed;
    bullet.move(delta_x, delta_y);
}
void Bullet::move_left1()
{
    float delta_x = -0.2, delta_y = -0.9;
    delta_x *= b_speed;
    delta_y *= b_speed;
    bullet.move(delta_x, delta_y);
}
void Bullet::move_left2()
{
    float delta_x = -0.5, delta_y = -0.8;
    delta_x *= b_speed;
    delta_y *= b_speed;
    bullet.move(delta_x, delta_y);
}
void Bullet::move_left4()
{
    float delta_x = -1, delta_y = -1;
    delta_x *= b_speed;
    delta_y *= b_speed;
    bullet.move(delta_x, delta_y);
}
void Bullet::move_right()
{
    float delta_x = 0.75, delta_y = -0.6;
    delta_x *= b_speed;
    delta_y *= b_speed;
    bullet.move(delta_x, delta_y);
}
void Bullet::move_right1()
{
    float delta_x = 0.2, delta_y = -0.9;
    delta_x *= b_speed;
    delta_y *= b_speed;
    bullet.move(delta_x, delta_y);
}
void Bullet::move_right2()
{
    float delta_x = 0.5, delta_y = -0.8;
    delta_x *= b_speed;
    delta_y *= b_speed;
    bullet.move(delta_x, delta_y);
}
void Bullet::move_right4()
{
    float delta_x = 1, delta_y = -1;
    delta_x *= b_speed;
    delta_y *= b_speed;
    bullet.move(delta_x, delta_y);
}
void Bullet::move()
{

    float delta_x = 0, delta_y = 0;
    delta_y = -1;

    delta_x *= b_speed;
    delta_y *= b_speed;

    bullet.move(delta_x, delta_y);
}
void Bullet::move_down()
{
    float delta_x = 0, delta_y = 0;
    
        delta_y = 1;
    delta_x *= b_speed;
    delta_y *= b_speed;

    bullet.move(delta_x, delta_y);
}
int Bullet::get_y()
{
    int x = bullet.getPosition().y;
    return x;
}
int Bullet::get_x()
{
    int a = bullet.getPosition().x;
    return a;
}