#include"invader.h"
#ifndef DB319220_12DC_46D1_B769_ED66CCE93D48
#define DB319220_12DC_46D1_B769_ED66CCE93D48

class Beta : public Invader
{
public:
    Beta(int x, int y);
    void fire(bool &i);
};

#endif /* DB319220_12DC_46D1_B769_ED66CCE93D48 */
