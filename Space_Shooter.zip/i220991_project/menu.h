#include <SFML/Graphics.hpp>
#include "game.cpp"
using namespace sf;
class Menu
{
public:
    // add menu attributes here
    Menu()
    {
        // constructors body
    }
    void display_menu()
    {

        // display menu screen here
        RenderWindow menu(VideoMode(780, 780), "MENU");
        Sprite bg;
        Texture bgtx;
        Mouse mouse;
        bool end_game = false;
        bgtx.loadFromFile("img/menu.png");
        bg.setTexture(bgtx);
        bool strt = false, high = false, instruct = false, stop = false;
        Image cursorImage;
        cursorImage.loadFromFile("img/PNG/UI/cursor.png");
        Cursor cursor;
        cursor.loadFromPixels(cursorImage.getPixelsPtr(), cursorImage.getSize(), {0, 0});
        menu.setMouseCursor(cursor);
        bool restart = false;
        string name;
        Font font;
        font.loadFromFile("Fonts/1.ttf");
        bool enter = false;

        Text text;
        text.setFont(font);
        text.setCharacterSize(24);
        text.setFillColor(Color::White);
        Text text1;
        text1.setFont(font);
        text1.setCharacterSize(35);
        text1.setFillColor(Color::White);
        text1.setPosition(200, 200);
        string playerName;
        text.setPosition(270, 400);
        text1.setString("Enter Username:");
        
        while (menu.isOpen())
        {
            if (Mouse::getPosition().y > 715 && Mouse::getPosition().y < 750)
            {
                if (Mouse::getPosition().x > 625 && Mouse::getPosition().x < 815)
                    if (Mouse::isButtonPressed(Mouse::Left))
                    {
                        enter = true;
                    }
            }
            if (Mouse::getPosition().y > 775 && Mouse::getPosition().y < 810)
            {
                if (Mouse::getPosition().x > 625 && Mouse::getPosition().x < 850)
                    if (Mouse::isButtonPressed(Mouse::Left))
                    {
                        instruct = true;
                    }
            }
            if (Mouse::getPosition().y > 830 && Mouse::getPosition().y < 870)
            {
                if (Mouse::getPosition().x > 625 && Mouse::getPosition().x < 805)
                    if (Mouse::isButtonPressed(Mouse::Left))
                    {
                        high = true;
                    }
            }
            if (Mouse::getPosition().y > 890 && Mouse::getPosition().y < 925)
            {
                if (Mouse::getPosition().x > 625 && Mouse::getPosition().x < 700)
                    if (Mouse::isButtonPressed(Mouse::Left))
                    {
                        stop = true;
                    }
            }

            // cout << Mouse::getPosition().x << " " << Mouse::getPosition().y << endl;
            Event e;
            while (menu.pollEvent(e))
            {
                if (e.type == Event::Closed)
                    menu.close();
                if (enter)
                    if (e.type == sf::Event::TextEntered)
                    {
                        if (e.text.unicode < 128)
                        {
                            if (e.text.unicode == '\b' && !playerName.empty())
                            {
                                playerName.pop_back(); // Remove the last character
                            }
                            else if (e.text.unicode != '\b')
                            {
                                playerName += static_cast<char>(e.text.unicode); // Append the typed character
                            }

                            text.setString(playerName); // Update the displayed text
                        }
                    }
                if (Keyboard::isKeyPressed(Keyboard::Key::Enter))
                {
                    strt = true;
                    enter = false;
                }
            }
            
            if (strt)
            {
                strt = false;
                Game g;
                g.start_game(restart,playerName);
            }
            if (restart)
            {
                restart = false;
                Game g;
                g.start_game(restart,playerName);
            }
            if (stop)
            {
                stop = false;
                menu.close();
            }
            if (instruct)
            {
                instruct = false;
                display_Instructions();
            }
            if (high)
            {
                high = false;
                displayHighScore();
            }

            menu.draw(bg);
            if(enter)
            {
                bgtx.loadFromFile("img/black.jpg");
                bg.setTexture(bgtx);
            }
            else{
                bgtx.loadFromFile("img/menu.png");
                bg.setTexture(bgtx);
            }
            if(enter)
            {
            menu.draw(text);
            menu.draw(text1);
            }
            menu.display();
        }
    }

    void display_Instructions()
    {
        Image cursorImage;
        cursorImage.loadFromFile("img/PNG/UI/cursor.png");
        Cursor cursor;
        cursor.loadFromPixels(cursorImage.getPixelsPtr(), cursorImage.getSize(), {0, 0});
        RenderWindow Inst(VideoMode(780, 780), "Instructions");
        Inst.setMouseCursor(cursor);
        Sprite bg;
        Texture bgtx;
        bgtx.loadFromFile("img/instructions.png");
        bg.setTexture(bgtx);
        bool stop = false;
        while (Inst.isOpen())
        {
            Event e;
            while (Inst.pollEvent(e))
            {
                if (Mouse::getPosition().y > 915 && Mouse::getPosition().y < 960)
                {
                    if (Mouse::getPosition().x > 1213 && Mouse::getPosition().x < 1330)
                        if (Mouse::isButtonPressed(Mouse::Left))
                        {
                            stop = true;
                        }
                }
                if (e.type == Event::Closed)
                    Inst.close();
                if (stop)
                {
                    stop = false;
                    return;
                }
            }
            Inst.draw(bg);
            Inst.display();
        }
    }
    void displayHighScore()
    {
        Sprite bg;
        Texture bgtx;
        bgtx.loadFromFile("img/highscore.png");
        bg.setTexture(bgtx);
        Image cursorImage;
        cursorImage.loadFromFile("img/PNG/UI/cursor.png");
        Cursor cursor;
        cursor.loadFromPixels(cursorImage.getPixelsPtr(), cursorImage.getSize(), {0, 0});
        RenderWindow high(VideoMode(780, 780), "High Score");
        high.setMouseCursor(cursor);
        Font font;
        font.loadFromFile("Fonts/1.ttf");
        Text name1;
        Text name2;
        Text name3;
        Text score1;
        Text score2;
        Text score3;
        name1.setFont(font);
        name2.setFont(font);
        name3.setFont(font);

        score1.setFont(font);
        score2.setFont(font);
        score3.setFont(font);

        ifstream file("score.txt");
        string n[3];
        int score[3];
        for (int i = 0; i < 3; i++)
        {
            file >> score[i];
            file >> n[i];
        }
        name1.setString(n[0]);
        name2.setString(n[1]);
        name3.setString(n[2]);
        score1.setString(to_string(score[0]));
        score2.setString(to_string(score[1]));
        score3.setString(to_string(score[2]));
        name1.setFillColor(Color::White);
        name2.setFillColor(Color::White);
        name3.setFillColor(Color::White);
        name1.setPosition(270, 260);
        name2.setPosition(270, 400);
        name3.setPosition(270, 540);
        score1.setFillColor(Color::White);
        score2.setFillColor(Color::White);
        score3.setFillColor(Color::White);
        score1.setPosition(360, 300);
        score2.setPosition(360, 440);
        score3.setPosition(360, 580);
        bool stop = false;
        while (high.isOpen())
        {
            // cout << Mouse::getPosition().x << " " << Mouse::getPosition().y << endl;
            Event e;
            while (high.pollEvent(e))
            {
                if (Mouse::getPosition().y > 890 && Mouse::getPosition().y < 950)
                {
                    if (Mouse::getPosition().x > 1243 && Mouse::getPosition().x < 1330)
                        if (Mouse::isButtonPressed(Mouse::Left))
                        {
                            stop = true;
                        }
                }
                if (e.type == Event::Closed)
                    high.close();
                if (stop)
                {
                    stop = false;
                    return;
                }
            }
            high.draw(bg);
            high.draw(name1);
            high.draw(name2);
            high.draw(name3);
            high.draw(score3);
            high.draw(score2);
            high.draw(score1);
            high.display();
        }
    }
};
