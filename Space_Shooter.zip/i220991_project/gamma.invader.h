#include"invader.h"
#ifndef CF61A4B3_22E4_4AE1_AC94_94B501690708
#define CF61A4B3_22E4_4AE1_AC94_94B501690708

class Gamma : public Invader
{
public:
    Gamma(int x, int y);
    void fire(bool &i);
    void Movel();
    void Mover();
};

#endif /* CF61A4B3_22E4_4AE1_AC94_94B501690708 */
