#include"fire_addon.h"

Fire::Fire() : AddOns("img/PNG/Power-ups/bolt_gold.png")
{
    visibility = true;
}
void Fire::move()
{
    float delta_x = 0, delta_y = 1;
    delta_x *= f_speed;
    delta_y *= f_speed;
    sprite.move(delta_x, delta_y);
}