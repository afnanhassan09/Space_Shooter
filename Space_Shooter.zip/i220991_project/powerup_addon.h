#include <iostream>
#include "addon.h"
#ifndef DBCC79BB_C6B4_4427_82DB_4FE00EFA4945
#define DBCC79BB_C6B4_4427_82DB_4FE00EFA4945

class PowerUp : public AddOns
{
public:
    PowerUp();
    void move();
};

#endif /* DBCC79BB_C6B4_4427_82DB_4FE00EFA4945 */
