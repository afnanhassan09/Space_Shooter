#include"addon.h"

AddOns::AddOns(string png_path)
{
    srand(time(0));
    text.loadFromFile(png_path);
    sprite.setTexture(text);
    int s = rand() % 780;
    sprite.setPosition(s, -10);
    f_speed = 0.2;
    visibility = false;
}