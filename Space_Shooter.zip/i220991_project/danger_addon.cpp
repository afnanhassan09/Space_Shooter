#include"danger_addon.h"

Danger::Danger() : AddOns("img/PNG/Lasers/laserRed10.png")
{
    visibility = true;
}
void Danger::move()
{
    float delta_x = 0, delta_y = 1;
    delta_x *= f_speed;
    delta_y *= f_speed;
    sprite.move(delta_x, delta_y);
}