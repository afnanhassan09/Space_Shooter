#include"dragon.h"

Dragon::Dragon()
{
    enemy.loadFromFile("img/dragon1.png");
    sprite.setTexture(enemy);
    sprite.setPosition(250, 0);
    score = 50;
    visibility = true;
    sprite.setScale(1.2, 1.2);
}
void Dragon::fire1()
{
    fire = new D_Fire;
}
void Dragon::fire2()
{
    fire = new D_Fire(9);
}
void Dragon::fire3()
{
    fire = new D_Fire(true);
}