#include <iostream>
#include "addon.h"
#ifndef ABB3F5D6_0ACC_45F0_8E41_3CC6C00FFE52
#define ABB3F5D6_0ACC_45F0_8E41_3CC6C00FFE52
class Lives : public AddOns
{
public:
    Lives();
    void move();
};

#endif /* ABB3F5D6_0ACC_45F0_8E41_3CC6C00FFE52 */
