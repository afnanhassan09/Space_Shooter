#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <fstream>
#include <time.h>
#include <iostream>
using namespace std;
#include "game.h"
using namespace sf;

Game::Game()
{
    p = new Player("img/player_ship.png");
    bg_texture.loadFromFile("img/bg.jpg");
    background.setTexture(bg_texture);
    background.setScale(1, 1);
}
void Game::start_game(bool &restart, string playerName)
{
    SoundBuffer ss;
    ss.loadFromFile("Sounds/song.ogg");
    Sound song;
    song.setBuffer(ss);
    song.setLoop(true);
    song.setVolume(50);
    song.play();
    if (!buffer1.loadFromFile("Sounds/shoot.ogg"))
    {
        // Error loading sound file
    }
    SoundBuffer start_sound;
    start_sound.loadFromFile("Sounds/wee.ogg");
    Sound starting_sound;
    starting_sound.setBuffer(start_sound);

    Sound shoot_sound;
    SoundBuffer buffer2;
    if (!buffer2.loadFromFile("Sounds/ship_destroy.ogg"))
    {
        // Error loading sound file
    }
    monster_file.loadFromFile("Sounds/monster.ogg");
    monster_sound.setBuffer(monster_file);
    ps.loadFromFile("img/pause.png");
    Pause.setTexture(ps);
    sound_destroy.setBuffer(buffer2);
    shoot_sound.setBuffer(buffer1);
    bool end_game = false;
    Image cursorImage;
    cursorImage.loadFromFile("img/PNG/UI/cursor.png");
    Cursor cursor;
    cursor.loadFromPixels(cursorImage.getPixelsPtr(), cursorImage.getSize(), {0, 0});
    srand(time(0));
    RenderWindow window(VideoMode(780, 780), title);
    window.setMouseCursor(cursor);
    RenderWindow pause;
    SoundBuffer dragonvoice;
    if (!dragonvoice.loadFromFile("Sounds/dragon.ogg"))
    {
    }
    Sound dragonsound;
    dragonsound.setBuffer(dragonvoice);
    Clock clock;
    float timer = 0;
    float beam_time = 0;
    float timer2 = 0;
    bool animating = false;
    bool stop_fire = false;
    float dragon_fire_time = 0;
    bool show_dragon = false;
    bool dragon_firing = false;
    bool dragon_fire = true;
    float timer3 = 0;
    float beaming = 0;
    float l_t = rand() % 20;
    float l_f = rand() % 10 + 1;
    float p_u = rand() % 20 + 1;
    float d_g = rand() % 20 + 1;
    float p_u_t = 0;
    float l_f_t = 0;
    float s_v = 0, s_e = 0;
    bool monster_beaming = false;
    bool enemy_bull[12];
    for (int i = 0; i < 12; i++)
    {
        enemy_bull[i] = false;
    }
    float time4 = 0;
    bool fire_bullet = false;
    int ship_visibility = 1;
    int i = 0, i2 = 0, i3 = 0, a = 0, b = 0;
    int l1e1 = 0;
    int uf1 = 0;
    int uf2 = 0;
    int uf3 = 0;
    int monster_appearance = rand() % 6 + 1;
    bool monster_start = false;
    float t = 0;
    float t2;
    float timer4 = 0;
    float timer5 = 0;
    int interval[12] = {0};
    for (int i = 0; i < 12; i++)
    {
        interval[i] = rand() % 10 + 1;
    }
    float e_b[12];
    for (int i = 0; i < 12; i++)
    {
        e_b[i] = 0;
    }

    bool stop_count[12];
    for (int i = 0; i < 12; i++)
    {
        stop_count[i] = true;
    }
    bool enemy_b = false;
    bool fire1 = true;
    bool fire2 = true;
    bool fire3 = true;
    bool collision = false;
    bool collide1 = true;
    bool collide2 = false;
    bool collide3 = false;
    bool start_3 = false, start_1 = true, start_2 = false, start_4 = false, start_5 = false, start_6 = false, start_7 = false, start_8 = false, start_9 = false;
    bool enemy_fire[12];
    for (int i = 0; i < 12; i++)
    {
        enemy_fire[i] = false;
    }
    Font font;
    font.loadFromFile("Fonts/1.ttf");
    Text score;
    score.setFont(font);
    score.setPosition(670, 740);
    score.setFillColor(Color::White);
    Text score1;
    score1.setFont(font);
    score1.setPosition(500, 740);
    score1.setFillColor(Color::White);
    score1.setString("Score : ");
    Text live;
    live.setFont(font);
    live.setPosition(10, 740);
    live.setFillColor(Color::White);
    live.setString("lives : ");
    Text level;
    level.setFont(font);
    level.setPosition(10, 40);
    level.setFillColor(Color::White);
    level.setString("Level : ");
    Text level1;
    level1.setFont(font);
    level1.setPosition(180, 40);
    level1.setFillColor(Color::White);
    while (window.isOpen())
    {
        // cout << p->sprite.getPosition().x << " " << p->sprite.getPosition().y << endl;
        score.setString(to_string(p->score));
        float time = clock.getElapsedTime().asSeconds();
        clock.restart();
        timer += time;
        timer2 += time;
        timer3 += time;
        timer4 += time;
        // timer5 += time;
        t += time;
        float t1;
        t1 += time;
        Event e;
        while (window.pollEvent(e))
        {
            if (e.type == Event::Closed) // If cross/close is clicked/pressed
            {
                end_game = true;
                window.close(); // close the game
            }
        }

        ////////////////////////////////////////////// checking movement keys ///////////////////////////////////////////////
        //
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Left) && sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Up))
        {
            p->tiltedLeft = true;
            if (Keyboard::isKeyPressed(sf::Keyboard::Key::Space))
                ;
            leftfire = true;
        }
        else
        {
            p->tiltedLeft = false;
            leftfire = false;
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Right) && sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Up))
        {
            p->tiltedRight = true;
            if (Keyboard::isKeyPressed(sf::Keyboard::Key::Space))
                rightfire = true;
        }
        else
        {
            p->tiltedRight = false;
            rightfire = false;
        }

        if (Keyboard::isKeyPressed(Keyboard::Left) && ship_visibility)  // If left key is pressed
            p->move("l");                                               // Player will move to left
        if (Keyboard::isKeyPressed(Keyboard::Right) && ship_visibility) // If right key is pressed
            p->move("r");                                               // player will move to right
        if (Keyboard::isKeyPressed(Keyboard::Up) && ship_visibility)    // If up key is pressed
            p->move("u");                                               // playet will move upwards
        if (Keyboard::isKeyPressed(Keyboard::Down) && ship_visibility)  // If down key is pressed
            p->move("d");

        ////////////////////////////////////// checing when to fire //////////////////////////////////////////////////
        if (Keyboard::isKeyPressed(Keyboard::Space) && ship_visibility) // If down key is pressed
        {
            if (!p->UltraFire)
            {
                if (bul_interval)
                {
                    p->fire1(i, bull_effect1); // firing each bullet after an interval
                    bul_interval = false;
                    i = 1;
                    if (rightfire)
                    {
                        rightbullet1 = true;
                    }
                    else
                        rightbullet1 = false;
                    if (leftfire)
                    {
                        leftbullet1 = true;
                    }
                    else
                        leftbullet1 = false;
                    shoot_sound.play();
                }
                if (bul_interval2)// firing each bullet after an interval
                {
                    bul_interval2 = false;
                    p->fire2(i2, bull_effect2);
                    if (rightfire)
                    {
                        rightbullet2 = true;
                    }
                    else
                        rightbullet2 = false;
                    if (leftfire)
                    {
                        leftbullet2 = true;
                    }
                    else
                        leftbullet2 = false;
                    i2 = 1;
                    shoot_sound.play();
                }
                if (bul_interval3)// firing each bullet after an interval
                {
                    p->fire3(i3, bull_effect3);
                    if (rightfire)
                    {
                        rightbullet3 = true;
                    }
                    else
                        rightbullet3 = false;
                    if (leftfire)
                    {
                        leftbullet3 = true;
                    }
                    else
                        leftbullet3 = false;
                    bul_interval3 = false;
                    i3 = 1;
                    shoot_sound.play();
                }
            }
            if (p->UltraFire)	// firing each bullet after an interval
            {
                if (bul_interval)
                {
                    p->ultrafire1(uf1);
                    shoot_sound.play();
                    bul_interval = false;
                }
                if (bul_interval2)
                {
                    p->ultrafire2(uf2);
                    shoot_sound.play();
                    bul_interval2 = false;
                }
                if (bul_interval3)
                {
                    p->ultrafire3(uf3);
                    shoot_sound.play();
                    bul_interval3 = false;
                }
            }
            if (t1 > 0.3)  //resetting and setting fire intervals
            {
                if (t1 > 0.3 && fire1)
                {
                    fire1 = false;
                    fire2 = true;
                    bul_interval = true;
                }
                if (t1 > 0.7 && fire2)
                {
                    fire2 = false;
                    fire3 = true;
                    bul_interval2 = true;
                }
                if (t1 > 1 && fire3)
                {
                    t1 = 0;
                    fire1 = true;

                    bul_interval3 = true;
                }
            }
        }

        // cout << "1\n";
        /////////////////////////////////////////////showing pause screen////////////////////////////////////////////////
        if (Keyboard::isKeyPressed(Keyboard::Escape)) // If down key is pressed
        {
            bool exit = false;
            bool resume = false;
            Image cursorImage;
            cursorImage.loadFromFile("img/PNG/UI/cursor.png");
            Cursor cursor;
            cursor.loadFromPixels(cursorImage.getPixelsPtr(), cursorImage.getSize(), {0, 0});

            pause.create(VideoMode(780, 780), "Pause Window");

            while (pause.isOpen())
            {
                Event p;
                while (pause.pollEvent(p)) // Event is occurring - until the game is in running state
                {
                    if (Mouse::getPosition().y > 720 && Mouse::getPosition().y < 780)
                    {
                        if (Mouse::getPosition().x > 840 && Mouse::getPosition().x < 1115)
                            if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
                            {
                                exit = true;
                            }
                    }
                    if (Mouse::getPosition().y > 600 && Mouse::getPosition().y < 665)
                    {
                        if (Mouse::getPosition().x > 840 && Mouse::getPosition().x < 1115)
                            if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
                            {
                                end_game = true;
                                restart = true;
                                pause.close();
                            }
                    }
                    if (Mouse::getPosition().y > 500 && Mouse::getPosition().y < 560)
                    {
                        if (Mouse::getPosition().x > 840 && Mouse::getPosition().x < 1115)
                            if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
                            {

                                resume = true;
                            }
                    }
                    if (p.type == Event::Closed) // If cross/close is clicked/pressed
                        pause.close();
                    if (resume)
                    {
                        pause.close();
                    }
                    if (exit)
                    {
                        end_game = true;
                        pause.close();
                        return;
                    }
                }
                pause.draw(Pause);
                pause.display();
            }
        }
        // cout << "2\n";
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        // cout << "3\n";
        /////////////////////////////////// setting random interval for the enemies ///////////////////////////////////////////
        if (l1e1)
            if (stop_count[0] || stop_count[1] || stop_count[2] || stop_count[3] || stop_count[4] || stop_count[5] || stop_count[6] || stop_count[7])
                for (int i = 0; i < 12; i++)
                {
                    e_b[i] += time;
                }
        if (l1e1)
        {
            for (int i = 0; i < 12; i++)
            {
                if ((e_b[i] > interval[i]) && stop_count[i])
                {

                    enemy_fire[i] = true;
                    stop_count[i] = false;
                    e_b[i] = 0;
                }
            }
        }
////////////////////////////////////// enemies firing //////////////////////////////////////////////////////
        if (l1e1)
            for (int i = 0; i < 12; i++)
            {
                if (p->l1.e[i]->visibility && enemy_fire[i])
                {
                    e_b[i] += time;
                    if (e_b[i] > p->l1.e[i]->bull_interval)
                    {
                        e_b[i] = 0;
                        p->l1.e[i]->fire(enemy_bull[i]);
                    }
                }
            }
        /////////////////////////////////// destroying the enemies //////////////////////////////////////////
        if (i)
        {
            p->destroy_enemy(l1e1, bull_effect1);
            firing = true;
        }
        if (i2)
        {
            p->destroy_enemy2(l1e1, bull_effect2);
            firing2 = true;
        }
        if (i3)
        {
            p->destroy_enemy3(l1e1, bull_effect3);
            firing3 = true;
        }
        //////////////////////////////////////////// deploying different enemies ///////////////////////////////////////
        int sum_1 = 0;
        if (l1e1)	// checking how many enemies are on the screen
        {
            for (int i = 0; i < 12; i++)
            {
                sum_1 += p->l1.e[i]->visibility;
            }
        }
        if (monster_start && sum_1 == 0)	// deploying the monster
        {
            monster_sound.play();
            p->l1.showMonster(monster);
            monster_start = false;
            monster_end = true;
        }
        if (monster_end)	// ending the monster
        {
            monster_ending += time;
            if (monster_ending > 8)
            {
                monster_ending = 0;
                monster_end = false;
                monster = false;
                if (monster_appearance == 1)
                    start_2 = true;
                if (monster_appearance == 2)
                    start_3 = true;
                if (monster_appearance == 3)
                    collide2 = true;
                if (monster_appearance == 4)
                    start_5 = true;
                if (monster_appearance == 5)
                    start_6 = true;
                if (monster_appearance == 6)
                    collide3 = true;
                p->score += 50;
            }
        }
        if (sum_1 == 0 && show_dragon1) 	// deploying the dragon
        {
            dragonsound.play();
            show_dragon1 = false;
            p->l1.showDragon(show_dragon);
        }
        if (dragon_firing)	// deploying dragon fire
        {
            dragon_fire_time += time;
            if (dragon_fire_time > 1)
            {
                dragon_fire_time = 0;
                dragon_firing = false;
            }
        }
        if (show_dragon)	// ending the dragon
        {
            dragon_showing += time;
            if (dragon_showing > 10)
            {
                dragon_showing = 0;
                show_dragon = false;
                p->score += 50;
                start_1=false;
            }
        }
        if (!dragon_firing && !stop_fire)	// resetting the position of the dragon
        {
            dragon_fire_time += time;
            if (dragon_fire_time > 0.1)
            {
                dragon_fire_time = 0;
                dragon_firing = true;
                dragon_fire = true;
            }
        }
        if (stop_fire)	// stopping the dragon fire once the player is hit
        {
            stop_interval += time;
            if (stop_interval > 2)
            {
                stop_fire = false;
                stop_interval = 0;
            }
        }
        if (show_dragon && dragon_fire)	// checking the position of the player to fire the laser
        {
            if (p->sprite.getPosition().x > 260 && p->sprite.getPosition().x < 520)
            {
                dragon_fire = false;
                p->l1.dragon->fire1();
                dragon_firing = true;
                if (p->sprite.getPosition().x > 260 && p->sprite.getPosition().x < 470)
                {
                    e_l = 0;
                    stop_fire = true;
                    p->destroy_ship(ship_visibility, crash);
                }
            }
            else if (p->sprite.getPosition().x < 260)
            {
                dragon_fire = false;
                p->l1.dragon->fire2();
                dragon_firing = true;
                if (p->sprite.getPosition().y > 660 && p->sprite.getPosition().y < 700)
                {
                    if (p->sprite.getPosition().x > -100 && p->sprite.getPosition().x < 132)
                    {
                        e_l = 0;
                        stop_fire = true;
                        p->destroy_ship(ship_visibility, crash);
                    }
                }
                else if (p->sprite.getPosition().y > 590 && p->sprite.getPosition().y < 660)
                {
                    if (p->sprite.getPosition().x > -100 && p->sprite.getPosition().x < 165)
                    {
                        e_l = 0;
                        stop_fire = true;
                        p->destroy_ship(ship_visibility, crash);
                    }
                }
                else if (p->sprite.getPosition().y > 520 && p->sprite.getPosition().y < 590)
                {
                    if (p->sprite.getPosition().x > 20 && p->sprite.getPosition().x < 215)
                    {
                        e_l = 0;
                        stop_fire = true;
                        p->destroy_ship(ship_visibility, crash);
                    }
                }
                else if (p->sprite.getPosition().y > 442 && p->sprite.getPosition().y < 520)
                {
                    if (p->sprite.getPosition().x > 40 && p->sprite.getPosition().x < 260)
                    {
                        e_l = 0;
                        stop_fire = true;
                        p->destroy_ship(ship_visibility, crash);
                    }
                }
            }
            else if (p->sprite.getPosition().x > 520)
            {
                dragon_fire = false;
                p->l1.dragon->fire3();
                dragon_firing = true;
                if (p->sprite.getPosition().y > 660 && p->sprite.getPosition().y < 700)
                {
                    if (p->sprite.getPosition().x > 580 && p->sprite.getPosition().x < 780)
                    {
                        e_l = 0;
                        stop_fire = true;
                        p->destroy_ship(ship_visibility, crash);
                    }
                }
                else if (p->sprite.getPosition().y > 590 && p->sprite.getPosition().y < 660)
                {
                    if (p->sprite.getPosition().x > 524 && p->sprite.getPosition().x < 780)
                    {
                        e_l = 0;
                        stop_fire = true;
                        p->destroy_ship(ship_visibility, crash);
                    }
                }
                else if (p->sprite.getPosition().y > 520 && p->sprite.getPosition().y < 590)
                {
                    if (p->sprite.getPosition().x > 480 && p->sprite.getPosition().x < 732)
                    {
                        e_l = 0;
                        stop_fire = true;
                        p->destroy_ship(ship_visibility, crash);
                    }
                }
            }
            // cout << "1\n";
        }
        if (sum_1 == 0 && t > 2 && (collide1 || collide2 || collide3))	// calling the animations 
        {
            if (collide1)
            {
                collide1 = false;
                start_1 = false;
            }
            if (collide2)
            {
                collide2 = false;
                start_4 = true;
            }
            if (collide3)
            {
                collide3 = false;
                start_7 = true;
            }
            p->collision(collision);
        }
        if (t > 5 && !start_1)	// Level 1
        {
            level1.setString("1");
            p->enemy_1(l1e1);
            start_1 = true;
            if (monster_appearance == 1)
                monster_start = true;
            else

                start_2 = true;
        }
        // cout << "5\n";
        if (sum_1 == 0 && start_2 && !monster)// Level 2
        {
            t2 += time;
            if (t2 > 2)
            {
                p->enemy_2(l1e1);
                start_2 = false;
                for (int i = 0; i < 12; i++)
                {
                    e_b[i] = 0;
                    stop_count[i] = true;
                    enemy_fire[i] = false;
                    enemy_bull[i] = false;
                }
                if (monster_appearance == 2)
                    monster_start = true;
                else

                    start_3 = true;
                t2 = 0;
            }
        }
        if (start_3 && sum_1 == 0 && !monster)// Level 3
        {
            t2 += time;
            if (t2 > 2)
            {
                p->enemy_3(l1e1);

                start_3 = false;
                for (int i = 0; i < 12; i++)
                {
                    e_b[i] = 0;
                    stop_count[i] = true;
                    enemy_fire[i] = false;
                    enemy_bull[i] = false;
                }
                if (monster_appearance == 3)
                    monster_start = true;
                else
                    collide2 = true;
                t2 = 0;
            }
        }
        if (start_4 && sum_1 == 0 && !monster)// Level 4
        {
            level1.setString("2");
            t2 += time;
            for (int i = 0; i < 12; i++)
            {
                p->l1.e[i]->sp += 0.5;
            }
            if (t2 > 2)
            {
                p->enemy_4(l1e1);

                start_4 = false;
                for (int i = 0; i < 12; i++)
                {
                    e_b[i] = 0;
                    stop_count[i] = true;
                    enemy_fire[i] = false;
                    enemy_bull[i] = false;
                }
                if (monster_appearance == 4)
                    monster_start = true;
                else

                    start_5 = true;
                t2 = 0;
            }
        }
        if (start_5 && sum_1 == 0 && !monster)	// Level 5
        {
            t2 += time;
            if (t2 > 2)
            {
                p->enemy_5(l1e1);

                start_5 = false;
                for (int i = 0; i < 12; i++)
                {
                    e_b[i] = 0;
                    stop_count[i] = true;
                    enemy_fire[i] = false;
                    enemy_bull[i] = false;
                }
                if (monster_appearance == 5)
                    monster_start = true;
                else

                    start_6 = true;
                t2 = 0;
            }
        }
        if (start_6 && sum_1 == 0 && !monster)	// Level 6
        {
            t2 += time;
            if (t2 > 2)
            {
                p->enemy_6(l1e1);

                start_6 = false;
                for (int i = 0; i < 12; i++)
                {
                    e_b[i] = 0;
                    stop_count[i] = true;
                    enemy_fire[i] = false;
                    enemy_bull[i] = false;
                }
                if (monster_appearance == 6)
                    monster_start = true;
                else

                    collide3 = true;
                t2 = 0;
            }
        }	
        if (start_7 && sum_1 == 0 && !monster)	// Level 7
        {	
            level1.setString("3");
            t2 += time;
            for (int i = 0; i < 12; i++)
            {
                p->l1.e[i]->sp += 0.5;
            }
            if (t2 > 2)
            {
                p->enemy_7(l1e1);

                start_7 = false;
                for (int i = 0; i < 12; i++)
                {
                    e_b[i] = 0;
                    stop_count[i] = true;
                    enemy_fire[i] = false;
                    enemy_bull[i] = false;
                }
                if (monster_appearance == 7)
                    monster_start = true;
                else

                    start_8 = true;
                t2 = 0;
            }
        }
        if (start_8 && sum_1 == 0 && !monster)	// Level 8
        {
            level1.setString("3");
            t2 += time;
            if (t2 > 2)
            {
                p->enemy_8(l1e1);

                start_8 = false;
                for (int i = 0; i < 12; i++)
                {
                    e_b[i] = 0;
                    stop_count[i] = true;
                    enemy_fire[i] = false;
                    enemy_bull[i] = false;
                }
                if (monster_appearance == 7)
                    monster_start = true;
                else

                    start_9 = true;
                t2 = 0;
            }
        }
        if (start_9 && sum_1 == 0 && !monster)	// Level 9
        {
            level1.setString("3");
            t2 += time;
            if (t2 > 2)
            {
                p->enemy_9(l1e1);

                start_9 = false;
                for (int i = 0; i < 12; i++)
                {
                    e_b[i] = 0;
                    stop_count[i] = true;
                    enemy_fire[i] = false;
                    enemy_bull[i] = false;
                }

                show_dragon1 = true;
                t2 = 0;
            }
        }
        // cout << "6\n";
        ////////////////////////////////////	calling different addons ///////////////////////////////////////////////
        if (timer2 > l_t && timer2 < l_t + 0.1)	
            p->Addon_life(li);
        if (timer2 > l_f && timer2 < l_f + 0.1)
        {
            p->Addon_fire(fi);
        }
        if (timer3 > p_u && timer3 < p_u + 0.1)
        {
            p->Addon_powerup(pu);
        }
        if (timer4 > d_g && timer4 < d_g + 0.1)
        {
            p->Addon_danger(dg);
            d_g = rand() % 15 + 10;
            timer4 = 0;
        }

        if (fi)
        {
            p->check_fire(fi);
        }
        if (pu)
        {
            p->check_power(pu);
        }
        if (dg)
        {
            p->check_danger(dg, ship_visibility, crash);
        }
        if (p->onFire)
        {
            l_f_t += time;
            if (l_f_t > 5)
            {
                l_f = rand() % 20;
                timer2 = 0;
                l_f_t = 0;
                p->onFire = false;
            }
        }

        if (p->PowerMode)
        {
            p_u_t += time;
            if (p_u_t > 5)
            {
                p_u = rand() % 20;
                timer3 = 0;
                p_u_t = 0;
                p->showShield = false;
                p->PowerMode = false;
                p->UltraFire = false;
            }
        }

        if (li)
        {
            p->check_life(li);
        }

        // cout << "7\n";
        /////////////////////////////////////////// resetting the ship visibility after it is destroyed //////////////////////////////////////////////////

        if (!ship_visibility)
        {
            s_v += time;
            if (s_v > 1)
            {
                s_v = 0;
                ship_visibility = 1;
            }
        }
        // cout << "8\n";
        /////////////////////////////////////// moving bullets ///////////////////////////////////////////////////
        if (i)
        {
            if (rightbullet1)
            {
                p->b1->move_right4();
            }
            else if (leftbullet1)
            {
                p->b1->move_left4();
            }
            else
                p->b1->move();
        }
        if (i2)
        {
            if (rightbullet2)
            {
                p->b2->move_right4();
            }
            else if (leftbullet2)
            {
                p->b2->move_left4();
            }
            else
            {
                p->b2->move();
            }
        }
        if (i3)
        {
            if (rightbullet3)
            {
                p->b3->move_right4();
            }
            else if (leftbullet3)
            {
                p->b3->move_left4();
            }
            else
                p->b3->move();
        }
        // cout << "9\n";
        ////////////////////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////
        /////  Call your functions here            ////
        p->Boundary_check();
        p->loadlife();
        //////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////////////////////
        window.clear(Color::Black); // clears the screen
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        window.draw(background);    // setting background
        window.draw(p->life);       // displaying the number of lives

///////////////////////////////////////////// drawing bullets///////////////////////////////////
        if (i) 
        {
            if (leftbullet1)
            {
            }
            if (p->b1->visibiity)
                window.draw(p->b1->bullet);
        }
        if (i2)	
            if (p->b2->visibiity)
                window.draw(p->b2->bullet);
        if (i3)
            if (p->b3->visibiity)
                window.draw(p->b3->bullet);
        if (ship_visibility)
            window.draw(p->sprite);
        // cout << "b1\n";
        if (uf1)
        {
            if (l1e1)
                p->ultra_fireDestroy1(l1e1);
            if (p->b4[0]->visibiity)
            {
                window.draw(p->b4[0]->bullet);
                p->b4[0]->move();
            }
            if (p->b4[1]->visibiity)
            {
                window.draw(p->b4[1]->bullet);
                p->b4[1]->move_left();
            }
            if (p->b4[2]->visibiity)
            {
                window.draw(p->b4[2]->bullet);
                p->b4[2]->move_right();
            }
            if (p->b4[3]->visibiity)
            {
                window.draw(p->b4[3]->bullet);
                p->b4[3]->move_left1();
            }
            if (p->b4[4]->visibiity)
            {
                window.draw(p->b4[4]->bullet);
                p->b4[4]->move_left2();
            }
            if (p->b4[5]->visibiity)
            {
                window.draw(p->b4[5]->bullet);
                p->b4[5]->move_right2();
            }
            if (p->b4[6]->visibiity)
            {
                window.draw(p->b4[6]->bullet);
                p->b4[6]->move_right1();
            }
        }
        // cout << "b2\n";
        if (uf2)
        {
            if (l1e1)
                p->ultra_fireDestroy2(l1e1);
            if (p->b5[0]->visibiity)
            {
                window.draw(p->b5[0]->bullet);
                p->b5[0]->move();
            }
            if (p->b5[1]->visibiity)
            {
                window.draw(p->b5[1]->bullet);
                p->b5[1]->move_left();
            }
            if (p->b5[2]->visibiity)
            {
                window.draw(p->b5[2]->bullet);
                p->b5[2]->move_right();
            }
            if (p->b5[3]->visibiity)
            {
                window.draw(p->b5[3]->bullet);
                p->b5[3]->move_left1();
            }
            if (p->b5[4]->visibiity)
            {
                window.draw(p->b5[4]->bullet);
                p->b5[4]->move_left2();
            }
            if (p->b5[5]->visibiity)
            {
                window.draw(p->b5[5]->bullet);
                p->b5[5]->move_right2();
            }
            if (p->b5[6]->visibiity)
            {
                window.draw(p->b5[6]->bullet);
                p->b5[6]->move_right1();
            }
        }
        if (uf3)
        {
            if (l1e1)
                p->ultra_fireDestroy3(l1e1);
            if (p->b6[0]->visibiity)
            {
                window.draw(p->b6[0]->bullet);
                p->b6[0]->move();
            }
            if (p->b6[1]->visibiity)
            {
                window.draw(p->b6[1]->bullet);
                p->b6[1]->move_left();
            }
            if (p->b6[2]->visibiity)
            {
                window.draw(p->b6[2]->bullet);
                p->b6[2]->move_right();
            }
            if (p->b6[3]->visibiity)
            {
                window.draw(p->b6[3]->bullet);
                p->b6[3]->move_left1();
            }
            if (p->b6[4]->visibiity)
            {
                window.draw(p->b6[4]->bullet);
                p->b6[4]->move_left2();
            }
            if (p->b6[5]->visibiity)
            {
                window.draw(p->b6[5]->bullet);
                p->b6[5]->move_right2();
            }
            if (p->b6[6]->visibiity)
            {
                window.draw(p->b6[6]->bullet);
                p->b6[6]->move_right1();
            }
        }
        // cout << "b3\n";
        
        /////////////////////////////////////////////////////drawing danger sign ////////////////////////////////
        if (dg)	
        {
            window.draw(p->danger->sprite);
            p->danger->move();
        }
        
        ///////////////////////////////////////////////////// drawing ship /////////////////////////////////////////
        if (ship_visibility)
        {
            if (p->tiltedLeft)
            {
                p->tex.loadFromFile("img/left_tilt.png");
                p->sprite.setTexture(p->tex);
                window.draw(p->sprite);
            }
            else if (p->tiltedRight)
            {
                p->tex.loadFromFile("img/right_tilt.png");
                p->sprite.setTexture(p->tex);
                window.draw(p->sprite);
            }
            else
            {
                p->tex.loadFromFile("img/player_ship.png");
                p->sprite.setTexture(p->tex);
                window.draw(p->sprite);
            }
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        if (l1e1)
        {
            for (int i = 0; i < 12; i++)
            {
                if (enemy_bull[i])
                {
                    window.draw(p->l1.e[i]->b->bullet);
                    p->l1.e[i]->b->move_down();
                }
            }
        }
        ///////////////////////////// The explosion animation /////////////////////////////////////////////////////////////
        if (!ship_visibility)
        {

            p->ex.loadFromFile("img/explosion.png");
            s_e += time;
            if (s_e > 0.25)
            {
                s_e = 0;
                IntRect textureRect(e_l, 0, 138, 138);
                e_l += 138;
                p->explosion.setTextureRect(textureRect);
            }
            window.draw(p->explosion);
        }

        ////////////////////Enemy bullet and ship collision //////////////////////////////////////////////////////////////
        if (l1e1)
        {
            for (int i = 0; i < 12; i++)
            {
                if (enemy_bull[i] && ship_visibility)
                {
                    e_l = 0;
                    if (p->l1.e[i]->b->bullet.getPosition().y > p->sprite.getPosition().y - 1 && p->l1.e[i]->b->bullet.getPosition().y < p->sprite.getPosition().y + 50)
                    {
                        if (p->l1.e[i]->b->bullet.getPosition().x > p->sprite.getPosition().x - 25 && p->l1.e[i]->b->bullet.getPosition().x < p->sprite.getPosition().x + 70)
                        {
                            p->destroy_ship(ship_visibility, crash);
                            sound_destroy.play();
                        }
                    }
                }
            }
        }
        ///////// Enemy and Ship collision
        if (l1e1)
        {
            for (int i = 0; i < 12; i++)
            {
                if (p->l1.e[i]->visibility && ship_visibility)
                {
                    e_l = 0;
                    if (p->l1.e[i]->sprite.getPosition().y > p->sprite.getPosition().y - 70 && p->l1.e[i]->sprite.getPosition().y < p->sprite.getPosition().y + 70)
                    {
                        if (p->l1.e[i]->sprite.getPosition().x > p->sprite.getPosition().x - 100 && p->l1.e[i]->sprite.getPosition().x < p->sprite.getPosition().x + 50)
                        {
                            p->destroy_ship(ship_visibility, crash);
                            sound_destroy.play();
                            p->l1.e[i]->visibility = false;
                        }
                    }
                }
            }
        }

        ///////////////////////////////////////// drawing enemies ///////////////////////////////////////////////
        if (l1e1)
        {
            for (int i = 0; i < 12; i++)
            {
                if (p->l1.e[i]->visibility)
                {
                    window.draw(p->l1.e[i]->sprite);
                }
            }
        }
        // cout << "1c1\n";
        //////////////////////////////// Add-ons ////////////////////////////////////////
        if (li)
            if (p->add_life->visibility)
            {
                window.draw(p->add_life->sprite);
                p->add_life->move();
            }

        if (fi)
            if (p->catch_fire->visibility)
            {
                window.draw(p->catch_fire->sprite);
                p->catch_fire->move();
            }
        if (pu)
        {
            if (p->power->visibility)
            {
                window.draw(p->power->sprite);
                p->power->move();
            }
        }
        if (p->showShield)
        {
            p->Sheild.setPosition(p->sprite.getPosition().x - 25, p->sprite.getPosition().y - 20);
            window.draw(p->Sheild);
        }
        
        ///////////////////////////////////////////////// Ending the game /////////////////////////////////////////////////////////////
        if (p->lives < 0)
        {
            end_game = true;
            show_endMenu = true;
            starting_sound.play();
        }
        if (end_game) //file handling
        {

            bool found = true;
            ifstream file("score.txt");
            ofstream tout("temp.txt");
            int x = 0;
            int in;
            string line;
            while (getline(file, line))
            {
                if (!line.empty())
                {
                    getline(file, line);
                    x++;
                }
            }
            file.close();
            file.open("score.txt");

            for (int i = 0; i < x; i++)
            {
                int j;
                string name;
                file >> j;
                file >> name;
                if (p->score > j && found)
                {
                    tout << p->score << endl;
                    tout << playerName << endl;
                    found = false;
                }
                tout << j << endl;
                tout << name << endl;
            }
            if (found)
            {
                tout << p->score << endl;
                tout << playerName << endl;
            }

            file.close();
            tout.close();
            remove("score.txt");
            rename("temp.txt", "score.txt");
            endtimer += time;
            if(endtimer>1)
            window.close();
        }
        if (show_endMenu)
        {
            Image cursorImage;
            cursorImage.loadFromFile("img/PNG/UI/cursor.png");
            Cursor cursor;
            cursor.loadFromPixels(cursorImage.getPixelsPtr(), cursorImage.getSize(), {0, 0});
            RenderWindow End(VideoMode(780, 780), "Game Over");
            End.setMouseCursor(cursor);
            Sprite bg;
            Texture bgtx;
            bool stop = false;
            bgtx.loadFromFile("img/end_game.png");
            bg.setTexture(bgtx);
            while (End.isOpen())
            {
                Event e;
                while (End.pollEvent(e))
                {
                    if (Mouse::getPosition().y > 915 && Mouse::getPosition().y < 960)
                    {
                        if (Mouse::getPosition().x > 1213 && Mouse::getPosition().x < 1330)
                            if (Mouse::isButtonPressed(Mouse::Left))
                            {
                                stop = true;
                            }
                    }
                    if (e.type == Event::Closed)
                        End.close();
                    if (stop)
                    {
                        stop = false;
                        return;
                    }
                }
                End.draw(bg);
                End.display();
            }
        }
        //////////////////////////////////////////// monster drawings /////////////////////////////////////////
        if (monster)
        {
            if (!monster_beam && !monster_beaming)
            {
                beam_time += time;
                if (beam_time > 2)
                {
                    beam_time = 0;
                    monster_beam = true;
                }
            }
            if (monster_beaming)
            {
                beaming += time;
                if (beaming > 2)
                {
                    beaming = 0;
                    monster_beaming = false;
                }
                if (p->l1.monster->b->bullet.getPosition().x > p->sprite.getPosition().x - 200 && p->l1.monster->b->bullet.getPosition().x < p->sprite.getPosition().x - 130 && ship_visibility)
                {
                    e_l = 0;
                    p->destroy_ship(ship_visibility, crash);
                }
            }
        }
        if (monster)
        {
            if (monster_beam)
            {
                monster_beam = false;
                p->l1.monster->fire_beam();
                monster_beaming = true;
            }
            if (monster_beaming)
            {
                window.draw(p->l1.monster->b->bullet);
                p->l1.monster->b->move(m_moveRight);
            }
            window.draw(p->l1.monster->sprite);
            if (p->l1.monster->sprite.getPosition().x < -200)
                m_moveRight = true;
            if (p->l1.monster->sprite.getPosition().x > 500)
                m_moveRight = false;
            p->l1.monster->move(m_moveRight);
        }
        
        ////////////////////////////////////////////////////// dragon drawings ////////////////////////////////////////////////////
        if (show_dragon)
        {
            window.draw(p->l1.dragon->sprite);
            if (dragon_firing)
                window.draw(p->l1.dragon->fire->bullet);
        }
        if (crash)
        {
            sound_destroy.play();
            crash = false;
        }
        if (collision)
        {
            if (p->l1.e1->sprite.getPosition().x > p->l1.e2->sprite.getPosition().x)
            {
                collision = false;
            }
            window.draw(p->l1.e1->sprite);
            window.draw(p->l1.e2->sprite);
            p->l1.e1->Mover();
            p->l1.e2->Movel();
        }
        
        //////////////////////////////////////////////////////// drawing texts /////////////////////////////////////////////////////////
        window.draw(score);
        window.draw(score1);
        window.draw(live);
        window.draw(level);
        window.draw(level1);
        window.display(); // Displaying all the sprites
    }
}
