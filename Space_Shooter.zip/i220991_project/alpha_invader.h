#include"invader.h"
#ifndef CD4697A9_B3C7_4343_8C0A_0E6AADC398DF
#define CD4697A9_B3C7_4343_8C0A_0E6AADC398DF

class Alpha : public Invader
{
public:
    Alpha(int x, int y);
    void fire(bool &i);
};

#endif /* CD4697A9_B3C7_4343_8C0A_0E6AADC398DF */
